import Navbar from './Navbar';
import UserDataTable from './UserDataTable';
import Academics from './Academics';
import AddToAcademics from './AddToAcademics';
import PushStudy from './PushStudy';
import Templates from './Templates'



export { Navbar, UserDataTable, Academics, AddToAcademics, PushStudy, Templates };