import React from 'react'

const UserDataTable = () => {
    return (
        <div>UserDataTable</div>
    )
}

export default UserDataTable